import * as pdfjsLib from "pdfjs-dist";
import pdfWorkerUrl from "pdfjs-dist/build/pdf.worker.min.mjs?url";
import mammoth from "mammoth/mammoth.browser";

pdfjsLib.GlobalWorkerOptions.workerSrc = pdfWorkerUrl;

/** Read plain text out of an uploaded PDF, Word (.docx) or text file. */
export async function extractText(file) {
  const name = file.name.toLowerCase();

  if (name.endsWith(".pdf")) {
    const pdf = await pdfjsLib.getDocument({ data: await file.arrayBuffer() }).promise;
    const pages = [];
    for (let i = 1; i <= pdf.numPages; i++) {
      const content = await (await pdf.getPage(i)).getTextContent();
      pages.push(`[Page ${i}]\n` + content.items.map((item) => item.str).join(" "));
    }
    return pages.join("\n\n").trim();
  }

  if (name.endsWith(".docx")) {
    const result = await mammoth.extractRawText({ arrayBuffer: await file.arrayBuffer() });
    return result.value.trim();
  }

  if (name.endsWith(".doc")) {
    throw new Error("Old .doc files aren't supported. Save it as .docx or PDF and try again.");
  }

  return (await file.text()).trim();
}
