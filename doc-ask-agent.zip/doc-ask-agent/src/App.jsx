import { useEffect, useMemo, useRef, useState } from "react";
import { extractText } from "./extractText.js";
import { SAMPLE_DOC } from "./sampleDoc.js";
import { buildIndex, answer } from "./agent.js";

const MAX_DOC_CHARS = 150_000;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

export default function App() {
  const [doc, setDoc] = useState(SAMPLE_DOC);
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [reading, setReading] = useState(false);
  const [uploadError, setUploadError] = useState("");
  const [dragOver, setDragOver] = useState(false);

  const abortRef = useRef(null);
  const fileInputRef = useRef(null);
  const endRef = useRef(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ block: "end", behavior: "smooth" });
  }, [messages]);

  async function handleFile(file) {
    if (!file) return;
    setUploadError("");
    setReading(true);
    try {
      const text = await extractText(file);
      if (!text) throw new Error("No readable text was found. If it's a scanned PDF, try a text-based copy.");
      abortRef.current?.abort();
      setDoc({ name: file.name, text, example: false });
      setMessages([]);
    } catch (err) {
      setUploadError(err.message || "Couldn't read that file. Try a PDF, .docx, .txt or .md file.");
    } finally {
      setReading(false);
    }
  }

  // Index the document once each time a new one is loaded.
  const index = useMemo(() => buildIndex(doc.text.slice(0, MAX_DOC_CHARS)), [doc]);

  async function ask(question) {
    const q = question.trim();
    if (!q || busy) return;

    const history = [...messages, { role: "user", content: q }];
    setMessages([...history, { role: "assistant", content: "", pending: true }]);
    setInput("");
    setBusy(true);

    const controller = new AbortController();
    abortRef.current = controller;

    try {
      const reply = answer(index, q, doc.name);

      // Short "reading" pause, then type the answer out like a chat agent.
      await sleep(500 + Math.random() * 400);
      const words = reply.text.split(/(\s+)/);
      let shown = "";
      for (let i = 0; i < words.length; i++) {
        if (controller.signal.aborted) break;
        shown += words[i];
        if (i % 2 === 0) {
          setMessages([...history, { role: "assistant", content: shown, miss: !reply.found }]);
          await sleep(18);
        }
      }
      setMessages([
        ...history,
        {
          role: "assistant",
          content: controller.signal.aborted ? shown : reply.text,
          miss: !reply.found,
          source: controller.signal.aborted ? null : reply.source,
        },
      ]);
    } catch (err) {
      console.error(err);
      setMessages([...history, { role: "error", content: "Something went wrong while searching the document. Try asking again." }]);
    } finally {
      setBusy(false);
    }
  }

  function clearChat() {
    abortRef.current?.abort();
    setMessages([]);
  }

  const wordCount = doc.text.split(/\s+/).filter(Boolean).length;
  const starters = doc.example
    ? ["What are the opening hours?", "How much is the Dedicated Desk?", "Is there parking?"]
    : ["Summarise this document", "What are the key points?", "What dates are mentioned?"];

  return (
    <div className="app">
      <header>
        <h1>
          Doc<span>Ask</span> Agent
        </h1>
        <span className="tag">Runs in your browser · no API key</span>
      </header>

      <div className="grid">
        {/* Left: the source document */}
        <section className="pane">
          <div className="pane-h">
            <h2>Source document</h2>
            <span className={"pill" + (doc.example ? " ex" : "")}>
              {doc.example ? "Example doc" : "Your doc"}
            </span>
          </div>

          <div className="side">
            <div
              className={"drop" + (dragOver ? " over" : "")}
              role="button"
              tabIndex={0}
              onClick={() => fileInputRef.current?.click()}
              onKeyDown={(e) => {
                if (e.key === "Enter" || e.key === " ") {
                  e.preventDefault();
                  fileInputRef.current?.click();
                }
              }}
              onDragOver={(e) => {
                e.preventDefault();
                setDragOver(true);
              }}
              onDragLeave={() => setDragOver(false)}
              onDrop={(e) => {
                e.preventDefault();
                setDragOver(false);
                handleFile(e.dataTransfer.files[0]);
              }}
            >
              <strong>{reading ? "Reading file…" : "Upload a document"}</strong>
              <small>Drop or click · PDF, DOCX, TXT, MD</small>
            </div>
            <input
              id="file"
              ref={fileInputRef}
              type="file"
              hidden
              accept=".pdf,.docx,.txt,.md,.csv,.json,.html"
              onChange={(e) => {
                handleFile(e.target.files[0]);
                e.target.value = "";
              }}
            />

            {uploadError && <div className="alert">{uploadError}</div>}

            <dl className="meta">
              <dt>File</dt>
              <dd>{doc.name}</dd>
              <dt>Words</dt>
              <dd>{wordCount.toLocaleString()}</dd>
              <dt>Characters</dt>
              <dd>{doc.text.length.toLocaleString()}</dd>
            </dl>

            {doc.text.length > MAX_DOC_CHARS && (
              <div className="alert">
                Only the first {MAX_DOC_CHARS.toLocaleString()} characters are used for answers.
              </div>
            )}

            <div className="preview" aria-label="Document preview">
              {doc.text.slice(0, 1500)}
              {doc.text.length > 1500 && "\n…"}
            </div>

            {doc.example && (
              <p className="note">
                This is a made-up example so you can try the agent straight away. Upload your own
                file to replace it.
              </p>
            )}
          </div>
        </section>

        {/* Right: the chat */}
        <section className="pane chat">
          <div className="pane-h">
            <h2>Ask the document</h2>
            {messages.length > 0 && (
              <button className="ghost" onClick={clearChat}>
                Clear chat
              </button>
            )}
          </div>

          <div className="msgs" aria-live="polite">
            {messages.length === 0 && (
              <div className="empty">
                <p>
                  Answers come only from <strong>{doc.name}</strong>. If something isn't in it, the
                  agent will say so.
                </p>
                <div className="chips">
                  {starters.map((s) => (
                    <button key={s} className="chip" disabled={busy} onClick={() => ask(s)}>
                      {s}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {messages.map((m, i) => {
              if (m.role === "user") return <div key={i} className="msg user">{m.content}</div>;
              if (m.role === "error") return <div key={i} className="msg err">{m.content}</div>;
              if (m.pending) return <div key={i} className="msg bot thinking">Reading the document…</div>;
              return (
                <div key={i} className={"msg bot" + (m.miss ? " miss" : "")}>
                  {m.miss && <span className="lbl">Not in this document</span>}
                  {m.content}
                  {m.source && <span className="src">From: {m.source}</span>}
                </div>
              );
            })}
            <div ref={endRef} />
          </div>

          <form
            onSubmit={(e) => {
              e.preventDefault();
              ask(input);
            }}
          >
            <textarea
              id="question"
              value={input}
              placeholder="Ask anything about this document…"
              aria-label="Your question"
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  ask(input);
                }
              }}
            />
            {busy ? (
              <button type="button" className="primary" onClick={() => abortRef.current?.abort()}>
                Stop
              </button>
            ) : (
              <button type="submit" className="primary" disabled={!input.trim()}>
                Ask
              </button>
            )}
          </form>
        </section>
      </div>
    </div>
  );
}
