/**
 * DocAsk local agent: answers questions from a document entirely in the browser.
 * No API key, no server. Uses BM25 keyword ranking over the document's sentences,
 * with section headings as extra context, then replies with the best passage.
 */

const STOPWORDS = new Set(
  `a about above after again all also am an and any are as at be because been before being below between both but by
  can could did do does doing down during each few for from further get got had has have having he her here hers him his
  how i if in into is it its itself just let like me more most much my no nor not now of off on once only or other our
  out over own please same she should so some such tell than that the their them then there these they this those
  through to too under until up very want was we were what when where which while who whom why will with would you your
  yours know give show explain find list say said`.split(/\s+/)
);

// Small synonym map so everyday wording still matches the document's wording.
const SYNONYMS = {
  cost: ["price", "fee", "pay", "charge", "$"],
  price: ["cost", "fee", "$"],
  fee: ["cost", "price", "$"],
  pay: ["cost", "price", "fee"],
  expensive: ["cost", "price"],
  cheap: ["cost", "price"],
  open: ["hour", "opening"],
  close: ["hour", "closed", "closing"],
  time: ["hour", "am", "pm"],
  hour: ["time", "open"],
  phone: ["contact", "call"],
  email: ["contact"],
  contact: ["phone", "email", "manager"],
  quit: ["cancel"],
  cancel: ["notice", "cancelled"],
  friend: ["guest"],
  visitor: ["guest"],
  wifi: ["wi", "fi", "internet", "password"],
  internet: ["wi", "fi", "wifi"],
  print: ["printing", "prints"],
  food: ["kitchen", "fridge"],
  drink: ["coffee", "tea", "water"],
  boss: ["manager"],
};

function stem(word) {
  if (word.length <= 3) return word;
  return word
    .replace(/(ies)$/, "y")
    .replace(/(ing|edly|ed|ly)$/, "")
    .replace(/(es)$/, "")
    .replace(/s$/, "");
}

function tokenize(text) {
  return (text.toLowerCase().replace(/wi-fi/g, "wifi").match(/\$|[a-z0-9]+(?:'[a-z]+)?/g) || [])
    .map((w) => w.replace(/'s$/, ""))
    .filter((w) => w && !STOPWORDS.has(w))
    .map(stem);
}

function expand(terms) {
  const out = new Map(); // term -> weight
  for (const t of terms) {
    out.set(t, Math.max(out.get(t) || 0, 1));
    for (const s of SYNONYMS[t] || []) {
      const st = stem(s);
      if (!out.has(st)) out.set(st, 0.5);
    }
  }
  return out;
}

const isHeading = (line) =>
  line.length > 0 &&
  line.length < 70 &&
  !/[.!?:,;]$/.test(line) &&
  (/^(\d+(\.\d+)*[.)]?\s+|#{1,6}\s+|[A-Z][A-Z0-9 &\-—–']{3,}$)/.test(line) || line.split(/\s+/).length <= 5);

const cleanHeading = (h) => {
  const t = h.replace(/^#{1,6}\s+|^\d+(\.\d+)*[.)]?\s+/, "").trim();
  // "LEAVE POLICY" -> "Leave policy"
  return t === t.toUpperCase() && /[A-Z]/.test(t) ? t.charAt(0) + t.slice(1).toLowerCase() : t;
};

/** Split the document into sentence-sized units that remember their section heading. */
export function buildIndex(text) {
  const units = [];
  const headings = [];
  let heading = "";

  for (const rawLine of text.split(/\n+/)) {
    const line = rawLine.trim();
    if (!line) continue;
    if (/^\[Page \d+\]$/.test(line)) continue;
    if (isHeading(line)) {
      heading = cleanHeading(line);
      if (heading && !headings.includes(heading)) headings.push(heading);
      continue;
    }
    const sentences = line.match(/[^.!?]+(?:[.!?]+(?=\s|$)|$)/g) || [line];
    for (const s of sentences) {
      const sentence = s.trim();
      if (sentence.length < 3) continue;
      units.push({
        text: sentence,
        heading,
        tokens: tokenize(sentence),
        headingTokens: tokenize(heading),
      });
    }
  }

  const df = new Map();
  for (const u of units) for (const t of new Set([...u.tokens, ...u.headingTokens])) df.set(t, (df.get(t) || 0) + 1);
  const avgLen = units.reduce((n, u) => n + u.tokens.length, 0) / Math.max(units.length, 1);
  const vocab = new Set(df.keys());

  return { units, headings, df, avgLen, vocab, N: units.length };
}

function scoreUnit(index, unit, query) {
  const k1 = 1.4, b = 0.75;
  let score = 0;
  const matched = new Set();
  for (const [term, weight] of query) {
    const df = index.df.get(term);
    if (!df) continue;
    const idf = Math.log(1 + (index.N - df + 0.5) / (df + 0.5));
    const tf = unit.tokens.filter((t) => t === term).length;
    if (tf) {
      score += weight * idf * ((tf * (k1 + 1)) / (tf + k1 * (1 - b + (b * unit.tokens.length) / index.avgLen)));
      matched.add(term);
    }
    if (unit.headingTokens.includes(term)) {
      score += weight * idf * 0.6;
      matched.add(term);
    }
  }
  return { score, matched };
}

const GREETING = /^(hi|hello|hey|kia ora|good (morning|afternoon|evening)|thanks|thank you|cheers)\b[\s!.]*$/i;
const OVERVIEW = /\b(summar(y|ise|ize)|overview|what is (this|the) (doc|document|file)|what('s| is) (it|this) about|key points|main points|topics)\b/i;

function topicList(headings) {
  if (headings.length <= 1) return headings.join("");
  if (headings.length <= 3) return headings.slice(0, -1).join(", ") + " and " + headings[headings.length - 1];
  return headings.slice(0, 3).join(", ") + ", and more";
}

/**
 * Answer a question from the indexed document.
 * Returns { text, found, source? }.
 */
export function answer(index, question, docName) {
  const q = question.trim();

  if (GREETING.test(q)) {
    return {
      found: true,
      text: /thank|cheers/i.test(q)
        ? "You're welcome! Ask me anything else about the document."
        : `Hi! I've read "${docName}". Ask me anything about it and I'll answer from what it says.`,
    };
  }

  if (OVERVIEW.test(q)) {
    if (index.headings.length >= 2) {
      return {
        found: true,
        text: `This document covers ${index.headings.length} main topics:\n\n` +
          index.headings.map((h) => `• ${h}`).join("\n") +
          "\n\nAsk me about any of them for the details.",
        source: "Document outline",
      };
    }
    const intro = index.units.slice(0, 3).map((u) => u.text).join(" ");
    return { found: true, text: `Here's how the document opens:\n\n${intro}`, source: "Opening lines" };
  }

  const baseTerms = [...new Set(tokenize(q))];
  const notFound = (term) => ({
    found: false,
    text:
      `I'm sorry, I couldn't find anything about ${term ? `"${term}"` : "that"} in this document.` +
      (index.headings.length
        ? ` It covers topics like ${topicList(index.headings)}. Try asking about one of those!`
        : " Try rephrasing your question using words from the document."),
  });

  if (!baseTerms.length) return notFound(null);

  // Words from the question that never appear in the document, even via synonyms.
  const missing = baseTerms.filter(
    (t) => !index.vocab.has(t) && !(SYNONYMS[t] || []).some((s) => index.vocab.has(stem(s)))
  );
  const coverage = 1 - missing.length / baseTerms.length;

  const query = expand(baseTerms);
  // "How much…" questions are about money: favour sentences with prices.
  if (/\bhow much\b|\b(cost|price|fee|charge|pay)/i.test(q)) query.set("$", 1);
  const ranked = index.units
    .map((u, i) => ({ i, u, ...scoreUnit(index, u, query) }))
    .filter((r) => r.score > 0)
    .sort((a, b) => b.score - a.score);

  const best = ranked[0];
  const missingWord = question.match(new RegExp(`\\b(${missing.map((m) => m.replace(/[^a-z0-9]/g, "")).join("|")})\\w*`, "i"))?.[0];

  // Not found: nothing matched, or the question's key words aren't in the document.
  if (!best || coverage < 0.5 || (missing.length && best.matched.size < 2)) {
    return notFound(missingWord || (missing[0] ?? null));
  }

  // Build the answer from the best sentence plus strong neighbours in the same section.
  const picked = new Set([best.i]);
  for (const r of ranked.slice(1, 6)) {
    if (picked.size >= 3) break;
    if (r.u.heading === best.u.heading && r.score >= best.score * 0.45 && r.matched.size >= best.matched.size) {
      picked.add(r.i);
    }
  }
  const sentences = [...picked]
    .sort((a, b) => a - b)
    .map((i) => index.units[i].text.replace(/^[-•*]\s+/, ""));

  return {
    found: true,
    text: sentences.join(" "),
    source: best.u.heading || null,
  };
}
