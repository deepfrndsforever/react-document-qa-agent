// A made-up example document so the demo works before anything is uploaded.
export const SAMPLE_DOC = {
  name: "Harbourview Co-working - Member Guide.txt",
  example: true,
  text: `HARBOURVIEW CO-WORKING — MEMBER GUIDE (2026)

1. Opening hours
The space is open 7:00am to 9:00pm Monday to Friday, and 9:00am to 5:00pm on Saturdays. We are closed on Sundays and public holidays. 24/7 access is included with the Dedicated Desk plan only.

2. Membership plans
- Casual Day Pass: $35 per day, hot desk, no meeting room credits.
- Flexi Member: $260 per month, 10 days per month, 2 hours of meeting room credit.
- Dedicated Desk: $520 per month, your own desk, lockable drawer, 24/7 access, 6 hours of meeting room credit.
All prices include GST. Plans can be cancelled with 30 days' written notice.

3. Meeting rooms
There are three meeting rooms: Kauri (8 people), Rimu (4 people) and the Phone Booth (1 person). Rooms are booked through the member app. Extra hours beyond your credit cost $25 per hour.

4. Wi-Fi and printing
Wi-Fi network: Harbourview-Members. The password is printed on the back of your access card. Each member gets 50 free black-and-white prints per month; colour prints are 40c each.

5. Kitchen
Free tea, coffee and filtered water. Please wash your own dishes. The fridge is cleared every Friday at 4pm.

6. Guests
Members may bring up to two guests per day. Guests must sign in at reception and be accompanied at all times.

7. Contact
Community manager: Aroha Tane, reception desk, Monday to Friday 9am–5pm.`,
};
