# DocAsk Agent

A React AI agent that answers questions **only from a document you upload**.
If the answer isn't in the document, it says so politely and suggests what the document does cover.

**No API key, no backend, no cost.** Everything runs in the browser.

## Features

- Upload **PDF, Word (.docx), .txt or .md** files (drag and drop or click)
- Answers come straight from the document, with the section they came from
- Friendly "not in this document" replies, highlighted in the chat
- Understands greetings and "summarise this document" questions
- Typing-style replies, a Stop button, clear chat, and a sample document so the demo works instantly
- Light and dark mode, and works on mobile
- Private: files never leave your computer

## Run it

You need **Node.js 18+**.

```bash
npm install
npm run dev
```

The app opens at **http://localhost:5173**.

## Demo script

1. Click **"How much is the Dedicated Desk?"**. The answer comes from the sample doc, with its section.
2. Type **"Is there parking?"**. You get a polite "not in this document" reply.
3. Type **"Summarise this document"**. You get a list of the topics it covers.
4. Upload your own PDF or Word file and ask about it.

## How it works

```
Upload file ─▶ Extract text ─▶ Split into sentences ─▶ Rank against question ─▶ Answer or "not found"
               (pdf.js /        (each remembers its      (BM25 keyword scoring
                mammoth)         section heading)         + synonyms)
```

| File | What it does |
| --- | --- |
| `src/extractText.js` | Reads text from PDF (pdf.js), Word (mammoth) and text files in the browser |
| `src/agent.js` | The agent: indexes the document and answers questions |
| `src/App.jsx` | The React UI: upload panel and chat |
| `src/sampleDoc.js` | A made-up example document for the demo |

**The agent (`src/agent.js`):**

1. **Indexing**: splits the document into sentences and remembers which section heading each one sits under.
2. **Understanding the question**: removes filler words ("what", "is", "the"), reduces words to their root (`cancelled` → `cancel`), and adds a few synonyms (`friend` → `guest`, `cost` → `price`).
3. **Ranking**: scores every sentence with **BM25**, the same ranking formula used in search engines like Elasticsearch. Matching the section heading adds extra weight.
4. **Deciding**: if the question's key words don't appear in the document, it replies politely that the information isn't there. Otherwise it returns the best sentence, plus closely related sentences from the same section.

## Limits and next steps

- This is retrieval only. It answers with the document's own sentences rather than writing new ones, so it never makes things up, but it can't combine facts or reword them.
- Scanned PDFs with no text layer need OCR first.
- **Upgrade path:** to get natural, written answers, send the top-ranked passages to an LLM (for example the Claude API) from a small backend. That's retrieval-augmented generation (RAG), and this project already does the retrieval part.
